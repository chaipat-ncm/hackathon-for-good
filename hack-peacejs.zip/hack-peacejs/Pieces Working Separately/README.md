# Know One's Team



```bash
paste -d ',' columns/* y.txt  > all_columns_combined.csv
```