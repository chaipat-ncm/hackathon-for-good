from django.apps import AppConfig


class NciaConfig(AppConfig):
    name = 'ncia'
